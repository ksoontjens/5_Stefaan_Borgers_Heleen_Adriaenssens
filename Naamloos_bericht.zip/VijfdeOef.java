﻿ import java.lang.*;
		
		/**
                 * De klasse EersteProg is een java applicatie
                 *
                 * @author Heleen Adriaenssens
                 * @version 1.5
                 */
	public class VijfdeOef{
		
		/**
		 * Dit is de main functie, hier start het programma
		 * @param args Dit is een parameter die kan meegegeven worden via de commandline
		 */

		public static void main(String args[])
		{
		int b=4302;
		int a=~b+1;
		System.out.println(a);
		}	
	}


