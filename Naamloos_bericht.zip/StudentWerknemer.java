public class StudentWerknemer extends PartTimeWerknemer
{
	public StudentWerknemers(String voornaam, String achternaam, int nr, float sal, int uren
}
